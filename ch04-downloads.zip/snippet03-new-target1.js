function example() {
    console.log(new.target);
}
example(); // undefined
