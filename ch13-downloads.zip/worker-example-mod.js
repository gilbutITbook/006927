export const example = a => a * 2;
