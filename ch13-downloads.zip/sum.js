export function sum(...numbers) {
    return numbers.reduce((a, b) => a + b);
}
