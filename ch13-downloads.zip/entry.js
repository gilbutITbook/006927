import { fn1 } from "./mod1.js";
import def, { fn2 } from "./mod2.js";

fn1();
fn2();
def();
