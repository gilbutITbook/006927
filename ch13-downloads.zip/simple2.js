import { log } from "./log2.js";

log("Hello, modules!");
