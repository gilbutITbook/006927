let obj = {first: 1, second: 2};
let {first} = obj;
console.log(first); // 1
