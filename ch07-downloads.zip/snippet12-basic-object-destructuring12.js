let { first, second } = 42;
console.log(first, second); // undefined undefined