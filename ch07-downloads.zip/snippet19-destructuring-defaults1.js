const obj = {first: 1, second: 2};
const {third = 3} = obj;
console.log(third); // 3
