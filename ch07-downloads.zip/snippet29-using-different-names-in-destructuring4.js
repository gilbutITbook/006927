const arr = [1, 2, 3, 4, 5];
const {1: b, 4: e} = arr;
console.log(b, e);  // 2 5
