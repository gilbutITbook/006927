const arr = [1, 2];
const [first, second] = arr;
console.log(first, second); // 1 2
