const obj = {"my-name": 1};
const {"my-name": myName} = obj;
console.log(myName);    // 1
