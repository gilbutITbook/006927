let obj = {first: 1, second: 2};
let {first: a} = obj;   // New destructuring syntax
console.log(a);         // 1
