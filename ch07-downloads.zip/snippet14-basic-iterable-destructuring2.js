const arr = [1, 2];
const [, second] = arr;
console.log(second);    // 2
