console.log("testing".includes("test"));    // true
console.log("testing".includes("test", 1)); // false
