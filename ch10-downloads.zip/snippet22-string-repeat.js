console.log("n".repeat(3)); // nnn
