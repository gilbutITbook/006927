console.log("testing".startsWith("test"));  // true
console.log("testing".endsWith("ing"));     // true
console.log("testing".endsWith("foo"));     // false
