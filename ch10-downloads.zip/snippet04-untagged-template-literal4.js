console.log(`Line 1
Line 2`);
