console.log("now testing".endsWith("test"));    // false
console.log("now testing".endsWith("test", 8)); // true
// Index 8 ----------^
