// Note: This file is encoded in UTF-8. Your system may or may not have a different default encoding.

console.log("\u{1F60A}"); // 😊 (smiling face emoji)
//           ^^^^^^^^^−−−− this is a code *point* escape
