console.log(`Not a substitution: \${foo}`); // Not a substitution: ${foo}
