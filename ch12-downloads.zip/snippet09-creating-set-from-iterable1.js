const s = new Set(["one", "two", "three"]);
console.log(s.has("two")); // true
