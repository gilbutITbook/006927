const s = new Set(["one", "two", "three", "one", "two", "three"]);
console.log(s.size); // 3
