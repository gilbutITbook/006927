let foo = () => {
};
console.log(foo.name);  // "foo"
