const obj = {};
obj.foo = function() {
};
console.log(obj.foo.name); // "" - there's no name
