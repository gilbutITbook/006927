const obj = {
    foo: function() {
    }
};
console.log(obj.foo.name); // "foo"
