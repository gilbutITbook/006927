let foo = function() {
};
console.log(foo.name);  // "foo"
