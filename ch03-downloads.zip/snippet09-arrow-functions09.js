const Doomed = () => { };
const d = new Doomed(); // TypeError: Doomed is not a constructor
