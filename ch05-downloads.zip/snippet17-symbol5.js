const mySymbol = Symbol("my symbol");
console.log(mySymbol.description); // "my symbol"
