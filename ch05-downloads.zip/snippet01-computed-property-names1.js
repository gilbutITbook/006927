var name = "answer";
var obj = {
    [name] : 42
};
console.log(obj); // {answer: 42}
