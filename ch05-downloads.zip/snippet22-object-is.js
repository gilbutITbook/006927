console.log(Object.is(+0, -0));     // false
console.log(Object.is(NaN, NaN));   // true
