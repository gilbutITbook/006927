const mySymbol = Symbol("my symbol");
console.log(mySymbol); // Symbol(my symbol)
