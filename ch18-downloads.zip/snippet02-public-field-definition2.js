class Example {
    answer = 42, question = "...";
    //         ^--- SyntaxError: Unexpected token, expected ";"
}
