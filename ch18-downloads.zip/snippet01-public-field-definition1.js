// ==== The snippet;

class Example {
    answer = 42;
}

// ==== Not in the snippet, but so you can see it in action:

console.log(new Example().answer); // 42
