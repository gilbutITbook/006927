// === The snippet:

class Example {
    answer;
    constructor(answer) {
        this.answer = answer;
    }
}

// ==== Not in the snippet, but so you can see it in action:

const e = new Example(42);
console.log(e.answer);      // 42
