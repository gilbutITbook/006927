console.log("a a a".replaceAll("a", "b"));  // "b b b"
