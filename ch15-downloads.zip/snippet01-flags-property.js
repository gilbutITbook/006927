const rex = /example/ig;
console.log(rex.flags); // "gi"
