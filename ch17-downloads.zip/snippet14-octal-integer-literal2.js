// This snippet demonstrates one of the problems with the old legacy octal literal.

// In loose mode only
console.log(011 === 09); // true
