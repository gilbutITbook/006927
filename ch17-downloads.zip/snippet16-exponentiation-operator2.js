// Syntax error
console.log(-2**2);
