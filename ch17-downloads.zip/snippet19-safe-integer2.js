const a = 2**53;
console.log(a); // 9007199254740992 (2**53)
const b = a + 1;
console.log(b); // 9007199254740992 (2**53) (again)
