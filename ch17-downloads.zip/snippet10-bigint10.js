console.log("$" + 2n); // $2
