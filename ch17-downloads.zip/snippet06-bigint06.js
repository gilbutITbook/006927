console.log(1n + 1); // => TypeError: Cannot mix BigInt and other types, use explicit conversions
