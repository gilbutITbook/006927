console.log(0b100); // 4 (in decimal)
