let x = 2;
x += 40;
console.log(x); // 42
