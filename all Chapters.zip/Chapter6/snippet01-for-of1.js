const a = ["a", "b", "c"];
for (const value of a) {
    console.log(value);
}
// =>
// "a"
// "b"
// "c"
