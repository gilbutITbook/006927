const a = [27, 14, 12, 64];
console.log(Math.min(... a)); // 12
