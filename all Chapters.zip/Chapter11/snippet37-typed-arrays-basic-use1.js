const a1 = new Int8Array(3);
console.log(a1); // Int8Array(3): [0, 0, 0]
