const a = new Int8Array(1);
a[0] = 25.4;
console.log(a[0]);  // 25
a[0] = -25.4;
console.log(a[0]);  // -25
