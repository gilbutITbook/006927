const a1 = new Int8Array(3);
a1[0] = 1;
a1[1] = "2";        // Note the string
a1[2] = 3;
console.log(a1);    // Int8Array(3): [1, 2, 3] -- note 2 is a number
