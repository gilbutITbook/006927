const str = "123";
const a = Array.from(str);
console.log(a); // ["1", "2", "3"]
