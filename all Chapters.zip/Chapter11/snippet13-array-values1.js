const a = ["one", "two", "three"];
for (const index of a.values()) {
    console.log(index);
}
// =>
// "one"
// "two"
// "three"