const a = Array(5).fill(42);
console.log(a); // [42, 42, 42, 42, 42]
