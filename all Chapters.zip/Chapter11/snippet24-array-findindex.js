const a = [1, 2, 3, 4, 5, 6];
const firstEven = a.findIndex(value => value % 2 == 0);
console.log(firstEven); // 1 -- the first even value is the number 2 at index 1
