const a = new Uint8Array(1);
a[0] = -25.4;
console.log(a[0]);  // 231 !?!!
