const a = Array.of("one", "two", "three");
console.log(a); // ["one", "two", "three"]
