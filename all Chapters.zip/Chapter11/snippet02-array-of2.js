const a = ["one", "two", "three"];
console.log(a); // ["one", "two", "three"]
