const a = new Int32Array(5);
console.log(a. buffer .byteLength); // 20 (bytes)
console.log(a.length);              // 5 (entries, each taking four bytes)
