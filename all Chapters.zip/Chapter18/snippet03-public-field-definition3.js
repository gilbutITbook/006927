// === The snippet:

class Example {
    answer = 42;
    question = "...";
}

// ==== Not in the snippet, but so you can see it in action:

const e = new Example();
console.log(e.answer);      // 42
console.log(e.question);    // "..."
