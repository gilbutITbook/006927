const value = Math.random();
console.log(value < 0.5 ? "Heads" : "Tails");
