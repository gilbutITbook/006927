function example() {
    console.log(answer); // undefined
    answer = 42;
    console.log(answer); // 42
    var answer = 67;
}
example();
