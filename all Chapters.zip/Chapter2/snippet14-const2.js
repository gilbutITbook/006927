const answer = 42;
console.log(answer); // 42
