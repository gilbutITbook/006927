let a;
console.log(a); // undefined
