const answer = 42;
console.log(answer); // 42
answer = 67; // TypeError: invalid assignment to const 'answer'
