// Note: This file is encoded in UTF-8. Your system may or may not have a different default encoding.

console.log(String.fromCodePoint(0x1F60A)); // 😊 (smiling face emoji)
