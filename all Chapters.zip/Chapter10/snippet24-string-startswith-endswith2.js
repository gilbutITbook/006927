console.log("now testing".startsWith("test"));      // false
console.log("now testing".startsWith("test", 4));   // true
// Index 4 ------^
