// Note: This file is encoded in UTF-8. Your system may or may not have a different default encoding.

console.log("\uD83D\uDE0A"); // 😊 (smiling face emoji)
//           ^^^^^^^^^^^^−−−− these are code *unit* escapes, you'll see a code *point* escape
//                            in the next snippet
