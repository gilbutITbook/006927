console.log("mod1 evaluation - begin");
export const one = "one";
console.log("mod1 evaluation - end");
