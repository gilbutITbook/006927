import { one   } from "./mod1.js";
import { two   } from "./mod2.js";
import { three } from "./mod3.js";

console.log("main evaluation - begin");

console.log(one, two, three);

console.log("main evaluation - end");
