// ==== The snippet:

const x = 10_000_000;

// ==== Not in the snippet, but so you can see it in action:

console.log(x);                     // 10000000
console.log(x.toLocaleString());    // "10,000,000"
