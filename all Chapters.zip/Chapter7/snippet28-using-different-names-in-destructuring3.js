const obj = {first: 1};
const {first: myName} = obj;
console.log(myName);    // 1
