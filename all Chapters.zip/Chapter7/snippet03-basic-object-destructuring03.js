let {first: a} = {first: 42};
console.log(a); // 42
