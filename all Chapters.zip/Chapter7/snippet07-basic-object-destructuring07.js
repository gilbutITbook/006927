const obj = { first: 1, second: 2 };
let { first, second } = obj;
console.log(first, second); // 1 2
