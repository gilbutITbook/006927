const arr = [1, 2];
let first, second;
[first, second] = arr;
console.log(first, second); // 1 2
