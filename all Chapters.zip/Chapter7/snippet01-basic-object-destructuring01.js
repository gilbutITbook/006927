let obj = {first: 1, second: 2};
let a = obj.first;  // Old, manual destructuring
console.log(a);     // 1
