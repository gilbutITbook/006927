function example(value = x) {
    var x = 42;
    console.log(value);
}
example(); // ReferenceError: x is not defined
