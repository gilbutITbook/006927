(function(callback = function() { }) {
    console.log(callback.name); // "callback"
})();
