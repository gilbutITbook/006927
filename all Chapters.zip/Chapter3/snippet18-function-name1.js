// Declaration
function foo() {
}
console.log(foo.name);  // "foo"

// Named function expression
const f = function bar() {
};
console.log(f.name);    // "bar"
