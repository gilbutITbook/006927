let foo;
foo = function() {
};
console.log(foo.name);  // "foo"
