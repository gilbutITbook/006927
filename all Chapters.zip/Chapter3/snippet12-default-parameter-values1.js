function animate(type, duration = 300) {
    console.log(type + ", " + duration);
}

animate("fadein");
animate("fadein", 400);
