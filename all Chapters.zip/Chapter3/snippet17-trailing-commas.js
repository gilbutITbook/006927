function example(
    question,   // (string) The question, must end with a question mark
    answer,     // (string) The answer, must end with appropriate punctuation
) {
    console.log("question: " + question);
    console.log("answer: " + answer);
}
example(
    "Do you like building software?",
    "Big time!",
);
