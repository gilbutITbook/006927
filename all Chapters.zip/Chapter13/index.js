import { sum } from "./sum.js";

console.log(`1 + 2 = ${sum(1, 2)}`);
