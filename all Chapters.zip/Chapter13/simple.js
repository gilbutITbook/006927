import { log } from "./log.js";

log("Hello, modules!");
