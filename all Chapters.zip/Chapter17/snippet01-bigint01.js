let a = 10000000000000000000n;
let b = a / 2n;
console.log(b); // 5000000000000000000n
let c = b * 3n;
console.log(c); // 15000000000000000000n
