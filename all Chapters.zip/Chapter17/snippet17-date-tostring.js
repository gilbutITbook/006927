console.log(new Date(2018, 11, 25, 8, 30, 15).toString());
// => Tue Dec 25 2018 08:30:15 GMT-0800 (Pacific Standard Time)
// or
// => Tue Dec 25 2018 08:30:15 GMT-0800
