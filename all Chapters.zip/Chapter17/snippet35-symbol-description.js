const s = Symbol("example");
console.log(s);             // Symbol(example)
console.log(s.description); // example
