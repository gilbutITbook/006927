console.log(2**8); // 256
