// Decimal
console.log(10n);   // 10n
// Hex
console.log(0x10n); // 16n
// Octal
console.log(0o10n); // 8n
