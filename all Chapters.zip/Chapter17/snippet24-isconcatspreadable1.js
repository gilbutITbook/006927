const a = ["one", "two"];
const b = ["four", "five"];
console.log(a.concat("three", b));
// => ["one", "two", "three", "four", "five"]
