console.log(BigInt(1.7));
// => RangeError: The number 1.7 cannot be converted to a BigInt
//    because it is not an integer
