console.log(0o10); // 8 (in decimal)
