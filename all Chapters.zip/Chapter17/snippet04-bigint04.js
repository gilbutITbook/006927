// Calling BigInt with a string:
let i = BigInt("1234567890123456789012345678");
console.log(i); // 1234567890123456789012345678n
// Calling BigInt with a number:
i = BigInt(9007199254740992);
console.log(i); // 9007199254740992n
