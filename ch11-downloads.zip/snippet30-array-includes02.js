const a = [NaN];
console.log(a.indexOf(NaN) !== -1); // false
console.log(a.includes(NaN));       // true
