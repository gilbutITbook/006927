const a = ["one", "two", "three"];
for (const index of a.keys()) {
    console.log(index);
}
// =>
// 0
// 1
// 2