const x = [].find(value => true);
console.log(x); // undefined