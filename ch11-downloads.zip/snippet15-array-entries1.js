const a = ["one", "two", "three"];
for (const entry of a.entries()) {
    console.log(entry);
}
// =>
// [0, "one"]
// [1, "two"]
// [2, "three"]